---
name: verification-before-completion
description: Use when about to claim work is complete, fixed, or passing, before committing or creating PRs. Invoke even when "pretty sure" the work is correct — no completion claim without fresh evidence from a just-run command; evidence before assertions always.
---

# Verification Before Completion

## Overview

Claiming work is complete without verification is dishonesty, not efficiency.

**Core principle:** Evidence before claims, always.

**Violating the letter of this rule is violating the spirit of this rule.**

## The Iron Law

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

If you haven't run the verification command in this message, you cannot claim it passes.

## The Gate Function

```
BEFORE claiming any status or expressing satisfaction:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute the FULL command (fresh, complete)
3. READ: Full output, check exit code, count failures
4. VERIFY: Does output confirm the claim?
   - If NO: State actual status with evidence
   - If YES: State claim WITH evidence
5. ONLY THEN: Make the claim

Skip any step = lying, not verifying
```

## Common Failures

| Claim | Requires | Not Sufficient |
|-------|----------|----------------|
| Tests pass | Test command output: 0 failures | Previous run, "should pass" |
| Linter clean | Linter output: 0 errors | Partial check, extrapolation |
| Build succeeds | Build command: exit 0 | Linter passing, logs look good |
| Bug fixed | Test original symptom: passes | Code changed, assumed fixed |
| Regression test works | Red-green cycle verified | Test passes once |
| Agent completed | VCS diff shows changes | Agent reports "success" |
| Requirements met | Line-by-line checklist | Tests passing |

## Red Flags - STOP

- Using "should", "probably", "seems to"
- Expressing satisfaction before verification ("Great!", "Perfect!", "Done!", etc.)
- About to commit/push/PR without verification
- Trusting agent success reports
- Relying on partial verification
- Thinking "just this once"
- Tired and wanting work over
- **ANY wording implying success without having run verification**

## Rationalization Prevention

| Excuse | Reality |
|--------|---------|
| "Should work now" | RUN the verification |
| "I'm confident" | Confidence ≠ evidence |
| "Just this once" | No exceptions |
| "Linter passed" | Linter ≠ compiler |
| "Agent said success" | Verify independently |
| "I'm tired" | Exhaustion ≠ excuse |
| "Partial check is enough" | Partial proves nothing |
| "Different words so rule doesn't apply" | Spirit over letter |

## Key Patterns

**Tests:**
```
✅ [Run test command] [See: 34/34 pass] "All tests pass"
❌ "Should pass now" / "Looks correct"
```

**Regression tests (TDD Red-Green):**
```
✅ Write → Run (pass) → Revert fix → Run (MUST FAIL) → Restore → Run (pass)
❌ "I've written a regression test" (without red-green verification)
```

**Build:**
```
✅ [Run build] [See: exit 0] "Build passes"
❌ "Linter passed" (linter doesn't check compilation)
```

**Requirements:**
```
✅ Re-read plan → Create checklist → Verify each → Report gaps or completion
❌ "Tests pass, phase complete"
```

**Agent delegation:**
```
✅ Agent reports success → Check VCS diff → Verify changes → Report actual state
❌ Trust agent report
```

## Why This Matters

Common failure patterns:
- Claiming tests pass without running them → trust broken when they don't
- Shipping undefined functions → crashes in production
- Missing requirements shipped → incomplete features discovered by users
- Time wasted on false completion → redirect → rework cycle

## When To Apply

**ALWAYS before final completion claims:**
- Claiming a task is done, fixed, complete, working, or passing
- Committing, PR creation, task completion
- Moving to the next task

**Does NOT apply to:**
- Interim progress reports ("Task 1 done, working on Task 2")
- Informational statements about what was changed
- Questions or clarifications

**Rule applies to:**
- Exact phrases ("it's done", "tests pass", "ready to merge")
- Paraphrases and synonyms
- Implications of final success

## Structured Report Format

When reporting verification results to the user, use this format:

| Phase | Check | Command (example) | Status |
|-------|-------|-------------------|--------|
| Build | Compiles without errors | `npm run build` / `cargo build` / `go build` | ✓ / ✗ |
| Types | No type errors | `tsc --noEmit` | ✓ / ✗ |
| Lint | No lint violations | `eslint` / `ruff` / `golangci-lint` | ✓ / ✗ |
| Tests | All pass, no regressions | `npm test` / `pytest` / `go test ./...` | ✓ / ✗ |
| Diff | Changes match stated intent | `git diff HEAD~1` | ✓ / ✗ |

**Rules:**
- Only include phases applicable to the project
- Skip phases where no tooling exists — don't fabricate checks
- Mark as **NOT RUN** if you could not run the check, not ✓
- Always include actual numbers: "47 passed, 0 failed" not just "✓"

**Example report:**
```
Verification complete:
- Build: ✓ (0 errors)
- Types: ✓ (0 type errors)
- Tests: ✓ (47 passed, 0 failed)
- Diff: ✓ (changes match task spec — added 1 endpoint, updated 1 test)
```

---

## The Bottom Line

**No shortcuts for verification.**

Run the command. Read the output. THEN claim the result.

This is non-negotiable.
